GITHUB PAGES UPDATE
1. Open https://github.com/md-akibul-hossain/md-akibul-hossain.github.io
2. Add file > Upload files. Upload index.html and MD_Akibul_Hossain_CV.pdf from this folder (NOT the ZIP).
3. Commit changes on main. Replace existing index.html.
4. Visit https://md-akibul-hossain.github.io and test View CV / Download CV.
